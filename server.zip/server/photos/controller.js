exports.add = (req, res) => {
  try {
    res.json({
      id: req.body.productId,
    });
  } catch (error) {
    res.status(500).send(err);
  }
};
